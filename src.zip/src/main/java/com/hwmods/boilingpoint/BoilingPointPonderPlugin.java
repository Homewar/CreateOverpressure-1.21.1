package com.hwmods.boilingpoint;

import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.createmod.ponder.api.scene.PonderStoryBoard;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.element.ElementLink;
import net.createmod.ponder.api.element.EntityElement;
import net.createmod.ponder.api.element.WorldSectionElement;

/**
 * Integrates with the real Create Ponder system. Once a scene is registered for an
 * item, Ponder automatically shows a "[W] Hold to Ponder" tooltip on that item and
 * opens this mod's scene when the player holds W while hovering it (same as Create).
 */
public class BoilingPointPonderPlugin implements PonderPlugin {

    private static final String MODID = BoilingPoint.MODID;

    @Override
    public String getModId() {
        return MODID;
    }

    @Override
    public void registerScenes(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        // Use empty schematic - we build everything from code
        ResourceLocation empty = helper.asLocation("empty");

        helper.addStoryBoard(rl("pneumatic_tube"), empty, tubeScene());
        helper.addStoryBoard(rl("pneumatic_connection"), empty, connectionScene());
        helper.addStoryBoard(rl("item_pump"), empty, pumpScene());
    }

    private ResourceLocation rl(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    /**
     * Build a 5x5 stone brick floor and show it as the base plate.
     */
    private ElementLink<WorldSectionElement> buildBasePlate(SceneBuilder scene, SceneBuildingUtil util) {
        scene.configureBasePlate(0, 0, 5);
        for (int x = 0; x < 5; x++) {
            for (int z = 0; z < 5; z++) {
                scene.world().setBlock(util.grid().at(x, 0, z), Blocks.STONE_BRICKS.defaultBlockState(), false);
            }
        }
        // Show all blocks at Y=0 as one independent section
        return scene.world().showIndependentSectionImmediately(util.select().fromTo(0, 0, 0, 4, 0, 4));
    }

    // region Scenes

    private PonderStoryBoard tubeScene() {
        return (SceneBuilder scene, SceneBuildingUtil util) -> {
            scene.title("pneumatic_tube", "Пневматические трубы");
            ElementLink<WorldSectionElement> floor = buildBasePlate(scene, util);
            scene.idle(10);

            // Place two chests and tubes, then show them all at once
            BlockPos chestA = util.grid().at(0, 1, 2);
            BlockPos chestB = util.grid().at(4, 1, 2);

            scene.world().setBlock(chestA, Blocks.CHEST.defaultBlockState(), false);
            scene.world().setBlock(chestB, Blocks.CHEST.defaultBlockState(), false);
            for (int x = 1; x <= 3; x++) {
                scene.world().setBlock(util.grid().at(x, 1, 2), ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);
            }

            // Show all blocks at Y=1
            ElementLink<WorldSectionElement> tubeSection = scene.world().showIndependentSectionImmediately(
                    util.select().fromTo(0, 1, 2, 4, 1, 2));
            scene.idle(15);

            scene.overlay().showText(60)
                    .text("Пневматические трубы соединяют контейнеры для перемещения предметов.")
                    .independent();
            scene.idle(70);

            scene.overlay().showText(60)
                    .text("Трубы автоматически соединяются между собой и с соседними блоками.")
                    .independent();
            scene.idle(70);

            // Animate an item flowing from chest A to chest B
            scene.overlay().showText(60)
                    .text("Предметы перемещаются по трубам от одного контейнера к другому.")
                    .independent();
            scene.idle(70);

            ItemStack diamond = new ItemStack(Items.DIAMOND);
            var item = scene.world().createItemEntity(new Vec3(0.5, 1.2, 2.5), Vec3.ZERO, diamond);
            for (int step = 0; step <= 40; step++) {
                double x = 0.5 + (4.0 * step / 40.0);
                double y = 1.2 + Math.sin(step / 40.0 * Math.PI) * 0.15;
                scene.world().modifyEntity(item, e -> e.setPos(x, y, 2.5));
                if (step % 8 == 0) {
                    scene.effects().emitParticles(new Vec3(x, 1, 2.5),
                            scene.effects().simpleParticleEmitter(ParticleTypes.END_ROD, Vec3.ZERO), 2, 1);
                }
                scene.idle(2);
            }
            scene.world().modifyEntity(item, e -> e.discard());
            scene.idle(10);

            // Show curvature tube example
            scene.overlay().showText(70)
                    .text("Трубы можно прокладывать под углом — они образуют плавные изогнутые соединения.")
                    .independent();
            scene.idle(80);

            // Hide old tubes, build L-shaped path
            scene.world().hideIndependentSection(tubeSection, Direction.DOWN);
            scene.idle(10);

            // Build L-shaped path
            scene.world().setBlock(util.grid().at(2, 1, 1), ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);
            scene.world().setBlock(util.grid().at(2, 1, 2), ModBlocks.CURVATURE_PNEUMATIC_TUBE.get().defaultBlockState(), false);
            scene.world().setBlock(util.grid().at(2, 2, 2), ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);
            scene.world().setBlock(util.grid().at(2, 1, 0), ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);

            scene.world().showIndependentSectionImmediately(
                    util.select().fromTo(2, 0, 0, 2, 2, 2));
            scene.idle(15);

            // Animate item going around the corner
            ItemStack emerald = new ItemStack(Items.EMERALD);
            var curved = scene.world().createItemEntity(new Vec3(2.5, 1.2, 0.5), Vec3.ZERO, emerald);
            for (int step = 0; step <= 40; step++) {
                final double t = step / 40.0;
                final double posX = 2.5;
                final double posZ;
                final double posY;
                if (t > 0.5) {
                    double cornerT = (t - 0.5) * 2.0;
                    posZ = 2.0 - cornerT * 0.5;
                    posY = 1.2 + cornerT * 0.8;
                } else {
                    posZ = 0.5 + t * 1.5;
                    posY = 1.2;
                }
                scene.world().modifyEntity(curved, e -> e.setPos(posX, posY, posZ));
                scene.idle(2);
            }
            scene.world().modifyEntity(curved, e -> e.discard());
            scene.idle(10);

            scene.overlay().showText(60)
                    .text("Изогнутые трубы позволяют прокладывать компактные маршруты.")
                    .independent();
            scene.idle(70);

            scene.markAsFinished();
        };
    }

    private PonderStoryBoard connectionScene() {
        return (SceneBuilder scene, SceneBuildingUtil util) -> {
            scene.title("pneumatic_connection", "Пневмо-коннектор");
            ElementLink<WorldSectionElement> floor = buildBasePlate(scene, util);
            scene.idle(10);

            // Place chest, connector, and tube
            BlockPos chest = util.grid().at(1, 1, 2);
            BlockPos connector = util.grid().at(2, 1, 2);
            BlockPos tube = util.grid().at(3, 1, 2);

            scene.world().setBlock(chest, Blocks.CHEST.defaultBlockState(), false);
            scene.world().setBlock(connector, ModBlocks.PNEUMATIC_CONNECTION.get().defaultBlockState(), false);
            scene.world().setBlock(tube, ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);

            // Show all blocks at once
            scene.world().showIndependentSectionImmediately(
                    util.select().fromTo(1, 1, 2, 3, 1, 2));
            scene.idle(15);

            scene.overlay().showText(70)
                    .text("Пневмо-коннектор соединяет трубу с контейнером и управляет перемещением предметов.")
                    .independent();
            scene.idle(80);

            scene.overlay().showText(70)
                    .text("По умолчанию коннектор выкачивает предметы из контейнера в трубу (режим экстрактора).")
                    .independent();
            scene.idle(80);

            // Animate item being pulled out of chest into tube
            ItemStack iron = new ItemStack(Items.IRON_INGOT);
            ElementLink<EntityElement> pulled = scene.world().createItemEntity(new Vec3(1.5, 1.2, 2.5), Vec3.ZERO, iron);
            for (int step = 0; step <= 20; step++) {
                double x = 1.5 + (1.0 * step / 20.0);
                scene.world().modifyEntity(pulled, e -> e.setPos(x, 1.2, 2.5));
                scene.idle(2);
            }
            scene.world().modifyEntity(pulled, e -> e.discard());
            scene.idle(10);

            scene.overlay().showText(50)
                    .text("Стрелка ОТ контейнера — режим извлечения (экстрактор).")
                    .independent();
            scene.idle(60);

            scene.overlay().showText(70)
                    .text("Используйте гаечный ключ, чтобы повернуть коннектор и сменить направление.")
                    .independent();
            scene.idle(80);

            // Rotate the connector
            ElementLink<WorldSectionElement> connSection =
                    scene.world().makeSectionIndependent(util.select().position(2, 1, 2));
            scene.world().rotateSection(connSection, 0, 180, 0, 30);
            scene.idle(40);

            scene.overlay().showText(70)
                    .text("Стрелка В контейнер — режим вставки. Предметы из трубы попадают в контейнер.")
                    .independent();
            scene.idle(80);

            // Animate item going into chest
            ItemStack gold = new ItemStack(Items.GOLD_INGOT);
            ElementLink<EntityElement> inserted = scene.world().createItemEntity(new Vec3(2.5, 1.2, 2.5), Vec3.ZERO, gold);
            for (int step = 0; step <= 20; step++) {
                double x = 2.5 - (1.0 * step / 20.0);
                scene.world().modifyEntity(inserted, e -> e.setPos(x, 1.2, 2.5));
                scene.idle(2);
            }
            scene.world().modifyEntity(inserted, e -> e.discard());
            scene.idle(10);

            scene.overlay().showText(70)
                    .text("В режиме экстрактора на коннектор можно установить фильтр из Create.")
                    .independent();
            scene.idle(80);

            // Show filter slot highlight
            scene.overlay().showOutline(PonderPalette.WHITE, new Object(),
                    util.select().position(2, 2, 2), 60);
            scene.idle(10);

            scene.overlay().showText(70)
                    .text("Кликните фильтром по верхней части коннектора — будет выкачивать только указанные предметы.")
                    .independent();
            scene.idle(80);

            // Show rejected item (stone) - doesn't pass through
            ItemStack stone = new ItemStack(Items.STONE);
            ElementLink<EntityElement> rejected = scene.world().createItemEntity(new Vec3(1.5, 1.2, 2.5), Vec3.ZERO, stone);
            scene.world().modifyEntity(rejected, e -> e.setPos(1.5, 1.2, 2.5));
            scene.idle(10);
            scene.world().modifyEntity(rejected, e -> e.discard());
            scene.idle(5);

            scene.overlay().showText(60)
                    .text("Предметы, не проходящие фильтр, остаются в контейнере.")
                    .independent();
            scene.idle(70);

            // Show filtered item (iron) passing through
            ItemStack ironFiltered = new ItemStack(Items.IRON_INGOT);
            ElementLink<EntityElement> filtered = scene.world().createItemEntity(new Vec3(1.5, 1.2, 2.5), Vec3.ZERO, ironFiltered);
            for (int step = 0; step <= 20; step++) {
                double x = 1.5 + (1.0 * step / 20.0);
                scene.world().modifyEntity(filtered, e -> e.setPos(x, 1.2, 2.5));
                scene.idle(2);
            }
            scene.world().modifyEntity(filtered, e -> e.discard());
            scene.idle(10);

            scene.overlay().showText(50)
                    .text("Только разрешённые фильтром предметы проходят в трубу.")
                    .independent();
            scene.idle(60);

            scene.markAsFinished();
        };
    }

    private PonderStoryBoard pumpScene() {
        return (SceneBuilder scene, SceneBuildingUtil util) -> {
            scene.title("item_pump", "Насос предметов");
            ElementLink<WorldSectionElement> floor = buildBasePlate(scene, util);
            scene.idle(10);

            // Place chests, tubes, and pump
            BlockPos chestA = util.grid().at(0, 1, 2);
            BlockPos chestB = util.grid().at(4, 1, 2);
            BlockPos pumpPos = util.grid().at(2, 1, 2);

            scene.world().setBlock(chestA, Blocks.CHEST.defaultBlockState(), false);
            scene.world().setBlock(chestB, Blocks.CHEST.defaultBlockState(), false);
            scene.world().setBlock(util.grid().at(1, 1, 2), ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);
            scene.world().setBlock(util.grid().at(3, 1, 2), ModBlocks.PNEUMATIC_TUBE.get().defaultBlockState(), false);
            scene.world().setBlock(pumpPos, ModBlocks.ITEM_PUMP.get().defaultBlockState(), false);

            // Show everything
            scene.world().showIndependentSectionImmediately(
                    util.select().fromTo(0, 1, 2, 4, 1, 2));
            scene.idle(15);

            scene.overlay().showText(70)
                    .text("Насос предметов ускоряет перемещение предметов по пневматическим трубам.")
                    .independent();
            scene.idle(80);

            scene.overlay().showText(70)
                    .text("Насос — это кинетический механизм Create. Ему требуется вращение от шестерни.")
                    .independent();
            scene.idle(80);

            scene.overlay().showText(60)
                    .text("Поставьте шестерню рядом с насосом, чтобы передать вращение.")
                    .independent();
            scene.idle(70);

            // Slow item animation (slow rotation)
            scene.overlay().showText(60)
                    .text("При медленном вращении предметы движутся неспешно.")
                    .independent();
            scene.idle(70);

            ItemStack slowItem = new ItemStack(Items.IRON_INGOT);
            ElementLink<EntityElement> slow = scene.world().createItemEntity(new Vec3(0.5, 1.2, 2.5), Vec3.ZERO, slowItem);
            for (int step = 0; step <= 60; step++) {
                double x = 0.5 + (4.0 * step / 60.0);
                scene.world().modifyEntity(slow, e -> e.setPos(x, 1.2, 2.5));
                if (step % 10 == 0) {
                    scene.effects().emitParticles(new Vec3(x, 1, 2.5),
                            scene.effects().simpleParticleEmitter(ParticleTypes.SMOKE, Vec3.ZERO), 1, 1);
                }
                scene.idle(2);
            }
            scene.world().modifyEntity(slow, e -> e.discard());
            scene.idle(10);

            // Spin pump then fast item animation
            scene.overlay().showText(60)
                    .text("Увеличьте скорость вращения — предметы полетят быстрее!")
                    .independent();
            scene.idle(70);

            ElementLink<WorldSectionElement> pumpSection =
                    scene.world().makeSectionIndependent(util.select().position(2, 1, 2));
            scene.world().rotateSection(pumpSection, 0, 360, 0, 20);
            scene.idle(25);

            ItemStack fastItem = new ItemStack(Items.GOLD_INGOT);
            ElementLink<EntityElement> fast = scene.world().createItemEntity(new Vec3(0.5, 1.2, 2.5), Vec3.ZERO, fastItem);
            for (int step = 0; step <= 25; step++) {
                double x = 0.5 + (4.0 * step / 25.0);
                scene.world().modifyEntity(fast, e -> e.setPos(x, 1.2, 2.5));
                if (step % 4 == 0) {
                    scene.effects().emitParticles(new Vec3(x, 1, 2.5),
                            scene.effects().simpleParticleEmitter(ParticleTypes.END_ROD, Vec3.ZERO), 1, 1);
                }
                scene.idle(2);
            }
            scene.world().modifyEntity(fast, e -> e.discard());
            scene.idle(10);

            scene.overlay().showText(70)
                    .text("Чем выше скорость вращения шестерни, тем быстрее насос перекачивает предметы.")
                    .independent();
            scene.idle(80);

            scene.overlay().showText(70)
                    .text("Насос также задаёт направление движения: предметы движутся вдоль оси насоса.")
                    .independent();
            scene.idle(80);

            scene.overlay().showText(60)
                    .text("Поверните насос гаечным ключом, чтобы сменить направление перекачки.")
                    .independent();
            scene.idle(70);

            scene.markAsFinished();
        };
    }

    // endregion
}